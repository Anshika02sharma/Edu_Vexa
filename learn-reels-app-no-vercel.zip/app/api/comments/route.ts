const comments: any[] = [
  {
    id: 1,
    reelId: "1",
    author: "Sarah Chen",
    text: "This is incredibly helpful!",
    timestamp: new Date().toISOString(),
  },
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const reelId = searchParams.get("reelId")

  const reelComments = comments.filter((c) => c.reelId === reelId)

  return Response.json({
    success: true,
    data: reelComments,
  })
}

export async function POST(request: Request) {
  const body = await request.json()

  const newComment = {
    id: comments.length + 1,
    ...body,
    timestamp: new Date().toISOString(),
  }

  comments.push(newComment)

  return Response.json({
    success: true,
    message: "Comment added",
    data: newComment,
  })
}
