export async function GET() {
  // Initialize demo users on first load
  if (typeof window === "undefined") {
    const demoUsers = [
      {
        id: "demo-user-1",
        name: "Demo User",
        email: "demo@eduvexa.com",
        password: "demo123",
        bio: "Welcome to EduVexa",
        avatar: "/diverse-avatars.png",
        followers: "25.5K",
        following: "342",
        reels: "128",
      },
    ]

    if (typeof localStorage !== "undefined") {
      const existingUsers = JSON.parse(localStorage.getItem("users") || "[]")
      if (!existingUsers.some((u: any) => u.email === "demo@eduvexa.com")) {
        localStorage.setItem("users", JSON.stringify([...existingUsers, ...demoUsers]))
      }
    }
  }

  return Response.json({ success: true, message: "Demo data initialized" })
}
