import { mockReels } from "@/lib/mock-data"

export async function GET() {
  return Response.json({
    success: true,
    data: mockReels,
  })
}
