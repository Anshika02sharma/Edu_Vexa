import { mockQuizzes } from "@/lib/mock-data"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const reelId = searchParams.get("reelId")

  const quiz = mockQuizzes.find((q) => q.reelId === reelId)

  if (!quiz) {
    return Response.json({ success: false, error: "Quiz not found" }, { status: 404 })
  }

  return Response.json({
    success: true,
    data: quiz,
  })
}
