import { mockReels } from "@/lib/mock-data"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const reel = mockReels.find((r) => r.id === params.id)

  if (!reel) {
    return Response.json({ success: false, error: "Reel not found" }, { status: 404 })
  }

  return Response.json({
    success: true,
    data: reel,
  })
}
