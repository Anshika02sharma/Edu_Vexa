export async function POST(request: Request) {
  const formData = await request.json()

  // Simulate file upload and processing
  const newReel = {
    id: Date.now().toString(),
    title: formData.title,
    description: formData.description,
    tags: formData.tags.split(",").map((t: string) => t.trim()),
    difficulty: formData.difficulty,
    thumbnail: "/uploaded.jpg",
    creator: {
      name: "Current User",
      followers: "1.2K",
      avatar: "/diverse-avatars.png",
    },
    duration: "1:30",
    views: 0,
    likes: 0,
    comments: 0,
    saves: 0,
    summary: "AI-generated summary will appear here after processing.",
  }

  return Response.json({
    success: true,
    message: "Reel uploaded successfully",
    data: newReel,
  })
}
