"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Navigation from "@/components/navigation"
import ReelFeed from "@/components/reel-feed"
import Sidebar from "@/components/sidebar"

export default function Home() {
  const router = useRouter()
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem("authToken")
    if (!token) {
      router.push("/auth")
      return
    }

    setIsAuthenticated(true)

    const savedDarkMode = localStorage.getItem("darkMode")
    const isDark =
      savedDarkMode === "true" || (savedDarkMode === null && window.matchMedia("(prefers-color-scheme: dark)").matches)
    setIsDarkMode(isDark)
    document.documentElement.classList.toggle("dark", isDark)
    setIsLoading(false)
  }, [router])

  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode
    setIsDarkMode(newDarkMode)
    localStorage.setItem("darkMode", String(newDarkMode))
    document.documentElement.classList.toggle("dark", newDarkMode)
  }

  if (isLoading) {
    return (
      <main className="bg-background min-h-screen flex items-center justify-center dark:bg-slate-950">
        <div className="text-center">
          <div className="w-12 h-12 rounded-lg flex items-center justify-center text-white text-lg font-bold bg-red-500 mx-auto mb-4">
            EV
          </div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </main>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <main className="bg-background dark:bg-slate-950 min-h-screen">
      <Navigation onToggleDarkMode={toggleDarkMode} isDarkMode={isDarkMode} />

      <div className="flex gap-0">
        <div className="flex-1 lg:flex-none lg:w-[480px] mx-auto lg:mx-0">
          <ReelFeed />
        </div>

        <div className="hidden lg:flex w-80 border-l border-border dark:border-slate-700 bg-secondary/30 dark:bg-slate-900/30">
          <Sidebar />
        </div>
      </div>
    </main>
  )
}
