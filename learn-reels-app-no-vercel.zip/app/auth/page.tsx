"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Eye, EyeOff } from "lucide-react"

export default function AuthPage() {
  const router = useRouter()
  const [isLogin, setIsLogin] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
  })
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    const token = localStorage.getItem("authToken")
    if (token) {
      router.push("/")
    }
  }, [router])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    setError("")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      if (isLogin) {
        if (!formData.email || !formData.password) {
          throw new Error("Please fill in all fields")
        }

        const mockUsers = JSON.parse(localStorage.getItem("users") || "[]")
        const user = mockUsers.find((u: any) => u.email === formData.email && u.password === formData.password)

        if (!user) {
          throw new Error("Invalid email or password")
        }

        localStorage.setItem("authToken", JSON.stringify({ email: formData.email, userId: user.id }))
        localStorage.setItem("currentUser", JSON.stringify(user))
        router.push("/")
      } else {
        if (!formData.email || !formData.password || !formData.name) {
          throw new Error("Please fill in all fields")
        }

        if (formData.password.length < 6) {
          throw new Error("Password must be at least 6 characters")
        }

        const mockUsers = JSON.parse(localStorage.getItem("users") || "[]")
        if (mockUsers.some((u: any) => u.email === formData.email)) {
          throw new Error("Email already registered")
        }

        const newUser = {
          id: Date.now().toString(),
          name: formData.name,
          email: formData.email,
          password: formData.password,
          bio: "Passionate learner",
          avatar: "/diverse-avatars.png",
          followers: "0",
          following: "0",
          reels: "0",
        }

        mockUsers.push(newUser)
        localStorage.setItem("users", JSON.stringify(mockUsers))
        localStorage.setItem("authToken", JSON.stringify({ email: formData.email, userId: newUser.id }))
        localStorage.setItem("currentUser", JSON.stringify(newUser))

        router.push("/")
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4 dark:bg-slate-950">
      <div className="w-full max-w-md">
        {/* Logo & Title */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="w-12 h-12 rounded-lg flex items-center justify-center text-white text-lg font-bold bg-red-500">
              EV
            </div>
            <div>
              <h1 className="text-2xl font-bold">EduVexa</h1>
              <p className="text-sm text-muted-foreground">Scroll. Learn. Grow.</p>
            </div>
          </div>

          <h2 className="text-3xl font-bold mb-2">{isLogin ? "Welcome Back" : "Join EduVexa"}</h2>
          <p className="text-muted-foreground">
            {isLogin ? "Sign in to continue learning" : "Create account to start learning"}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-sm font-medium mb-2">Full Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Sarah Chen"
                className="w-full px-4 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-red-500 text-foreground dark:bg-slate-900 dark:border-slate-700"
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="your@email.com"
              className="w-full px-4 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-red-500 text-foreground dark:bg-slate-900 dark:border-slate-700"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="••••••••"
                className="w-full px-4 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-red-500 text-foreground dark:bg-slate-900 dark:border-slate-700"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-600 text-sm">{error}</div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 transition disabled:opacity-50"
          >
            {isLoading ? "Please wait..." : isLogin ? "Sign In" : "Create Account"}
          </button>
        </form>

        {/* Toggle Auth Mode */}
        <div className="mt-6 text-center">
          <p className="text-muted-foreground">
            {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
            <button
              onClick={() => {
                setIsLogin(!isLogin)
                setError("")
                setFormData({ email: "", password: "", name: "" })
              }}
              className="text-red-500 font-semibold hover:text-red-600"
            >
              {isLogin ? "Sign Up" : "Sign In"}
            </button>
          </p>
        </div>

        {/* Demo Credentials */}
        <div className="mt-8 p-4 rounded-lg bg-secondary/30 border border-border">
          <p className="text-xs font-semibold mb-2">Demo Credentials:</p>
          <p className="text-xs text-muted-foreground">Email: demo@eduvexa.com</p>
          <p className="text-xs text-muted-foreground">Password: demo123</p>
        </div>
      </div>
    </div>
  )
}
