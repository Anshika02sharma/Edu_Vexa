"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Bookmark, Download } from "lucide-react"
import ReelPlayer from "@/components/reel-player"
import CommentSection from "@/components/comment-section"
import QuizModal from "@/components/quiz-modal"
import { mockReels } from "@/lib/mock-data"

export default function ReelPage() {
  const params = useParams()
  const router = useRouter()
  const [reel, setReel] = useState<any>(null)
  const [isLiked, setIsLiked] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const [showQuiz, setShowQuiz] = useState(false)
  const [showAddToCourse, setShowAddToCourse] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)

  useEffect(() => {
    const token = localStorage.getItem("authToken")
    if (!token) {
      router.push("/auth")
      return
    }

    const foundReel = mockReels.find((r) => r.id === params.id)
    setReel(foundReel)

    const isDark = localStorage.getItem("darkMode") === "true"
    setIsDarkMode(isDark)
    document.documentElement.classList.toggle("dark", isDark)
  }, [params.id, router])

  if (!reel) {
    return (
      <div className="h-screen flex items-center justify-center bg-background dark:bg-slate-950">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-500"></div>
      </div>
    )
  }

  return (
    <main className="bg-background dark:bg-slate-950 min-h-screen">
      {/* Header */}
      <div className="border-b border-border dark:border-slate-700 sticky top-0 bg-background/80 dark:bg-slate-950/80 backdrop-blur-sm z-40">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-4">
          <Link href="/" className="p-2 hover:bg-secondary dark:hover:bg-slate-800 rounded-lg smooth">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="font-bold text-lg">{reel.title}</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Video Player */}
          <div className="lg:col-span-2">
            <ReelPlayer reel={reel} autoplayWithSound={true} />

            {/* Reel Info */}
            <div className="mt-6 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-2xl font-bold">{reel.title}</h1>
                  <p className="text-muted-foreground mt-2">{reel.description}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setIsLiked(!isLiked)}
                    className={`p-3 rounded-lg border smooth ${
                      isLiked
                        ? "bg-red-500/20 border-red-500 text-red-500"
                        : "border-border dark:border-slate-700 hover:border-red-500"
                    }`}
                  >
                    <Heart className="w-5 h-5" fill={isLiked ? "currentColor" : "none"} />
                  </button>
                  <button
                    onClick={() => setIsSaved(!isSaved)}
                    className={`p-3 rounded-lg border smooth ${
                      isSaved
                        ? "bg-yellow-500/20 border-yellow-500 text-yellow-500"
                        : "border-border dark:border-slate-700 hover:border-yellow-500"
                    }`}
                  >
                    <Bookmark className="w-5 h-5" fill={isSaved ? "currentColor" : "none"} />
                  </button>
                </div>
              </div>

              {/* Tags & Meta */}
              <div className="pt-4 border-t border-border dark:border-slate-700 space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Tags</p>
                  <div className="flex flex-wrap gap-2">
                    {reel.tags.map((tag, i) => (
                      <span key={i} className="px-3 py-1 rounded-full bg-secondary dark:bg-slate-800 text-sm">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Difficulty</p>
                    <p className="font-semibold text-sm">{reel.difficulty}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Duration</p>
                    <p className="font-semibold text-sm">{reel.duration}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Views</p>
                    <p className="font-semibold text-sm">{reel.views}</p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 grid grid-cols-2 gap-3">
                <button
                  onClick={() => setShowQuiz(true)}
                  className="px-4 py-3 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 smooth"
                >
                  Practice Quiz
                </button>
                <button
                  onClick={() => setShowAddToCourse(true)}
                  className="px-4 py-3 border border-border dark:border-slate-700 rounded-lg font-semibold hover:bg-secondary dark:hover:bg-slate-800 smooth"
                >
                  Add to Course
                </button>
              </div>

              {/* AI Summary */}
              <div className="p-4 bg-secondary/50 dark:bg-slate-800/50 rounded-lg border border-border dark:border-slate-700">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Download className="w-4 h-4" />
                  AI Summary
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{reel.summary}</p>
              </div>

              {/* Creator Info */}
              <div className="p-4 border border-border dark:border-slate-700 rounded-lg">
                <div className="flex items-center gap-3">
                  <Image
                    src={reel.creator.avatar || "/placeholder.svg"}
                    alt={reel.creator.name}
                    width={50}
                    height={50}
                    className="rounded-full"
                  />
                  <div className="flex-1">
                    <p className="font-semibold">{reel.creator.name}</p>
                    <p className="text-sm text-muted-foreground">{reel.creator.followers} followers</p>
                  </div>
                  <button className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-semibold hover:bg-red-600">
                    Follow
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Comments & Related */}
          <div className="lg:col-span-1">
            <div className="sticky top-20 space-y-6">
              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 bg-secondary/50 dark:bg-slate-800/50 rounded-lg">
                  <p className="text-xs text-muted-foreground">Likes</p>
                  <p className="font-bold">{reel.likes}</p>
                </div>
                <div className="p-3 bg-secondary/50 dark:bg-slate-800/50 rounded-lg">
                  <p className="text-xs text-muted-foreground">Comments</p>
                  <p className="font-bold">{reel.comments}</p>
                </div>
              </div>

              {/* Comments */}
              <CommentSection reelId={reel.id} />
            </div>
          </div>
        </div>
      </div>

      {/* Quiz Modal */}
      {showQuiz && <QuizModal reelId={reel.id} onClose={() => setShowQuiz(false)} />}

      {/* Add to Course Modal */}
      {showAddToCourse && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-background dark:bg-slate-900 rounded-lg p-6 max-w-sm w-full border border-border dark:border-slate-700">
            <h2 className="font-bold text-lg mb-4">Add to Micro-course</h2>
            <div className="space-y-2 mb-6">
              <p className="text-sm text-muted-foreground">Select a course or create a new one:</p>
              <button className="w-full p-3 text-left rounded-lg border border-border dark:border-slate-700 hover:border-red-500 hover:bg-red-500/5 smooth">
                Web Development Basics
              </button>
              <button className="w-full p-3 text-left rounded-lg border border-border dark:border-slate-700 hover:border-red-500 hover:bg-red-500/5 smooth">
                React Advanced
              </button>
              <button className="w-full p-3 text-left rounded-lg border border-dashed border-red-500 hover:bg-red-500/10 smooth">
                + Create New Course
              </button>
            </div>
            <button
              onClick={() => setShowAddToCourse(false)}
              className="w-full px-4 py-2 border border-border dark:border-slate-700 rounded-lg hover:bg-secondary dark:hover:bg-slate-800 smooth"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </main>
  )
}
