"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Navigation from "@/components/navigation"
import UploadReelForm from "@/components/upload-reel-form"

export default function UploadPage() {
  const router = useRouter()
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem("authToken")
    if (!token) {
      router.push("/auth")
      return
    }

    const isDark = localStorage.getItem("darkMode") === "true"
    setIsDarkMode(isDark)
    document.documentElement.classList.toggle("dark", isDark)
    setIsLoading(false)
  }, [router])

  const handleToggleDarkMode = () => {
    const newDarkMode = !isDarkMode
    setIsDarkMode(newDarkMode)
    localStorage.setItem("darkMode", String(newDarkMode))
    document.documentElement.classList.toggle("dark", newDarkMode)
  }

  if (isLoading) return null

  return (
    <main className="bg-background dark:bg-slate-950 min-h-screen">
      <Navigation isDarkMode={isDarkMode} onToggleDarkMode={handleToggleDarkMode} />

      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Upload a Reel</h1>
          <p className="text-muted-foreground">Share your knowledge with the EduVexa community</p>
        </div>

        <UploadReelForm />
      </div>
    </main>
  )
}
