import { type NextRequest, NextResponse } from "next/server"

export function middleware(request: NextRequest) {
  const authToken = request.cookies.get("authToken")?.value || localStorage?.getItem?.("authToken")

  const publicPaths = ["/auth", "/api"]
  const isPublicPath = publicPaths.some((path) => request.nextUrl.pathname.startsWith(path))

  if (!authToken && !isPublicPath) {
    return NextResponse.redirect(new URL("/auth", request.url))
  }

  if (authToken && request.nextUrl.pathname === "/auth") {
    return NextResponse.redirect(new URL("/", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!_next|static|public).*)"],
}
