"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Navigation from "@/components/navigation"
import { BookOpen } from "lucide-react"

export default function MyLearning() {
  const router = useRouter()
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [courses, setCourses] = useState([])

  useEffect(() => {
    const token = localStorage.getItem("authToken")
    if (!token) {
      router.push("/auth")
      return
    }

    const isDark = localStorage.getItem("darkMode") === "true"
    setIsDarkMode(isDark)
    document.documentElement.classList.toggle("dark", isDark)

    // Mock data
    setCourses([
      { id: 1, title: "React Advanced Patterns", progress: 65, duration: "4h 30m", enrolled: 25 },
      { id: 2, title: "TypeScript Fundamentals", progress: 40, duration: "3h", enrolled: 18 },
      { id: 3, title: "Next.js 15 Deep Dive", progress: 85, duration: "5h", enrolled: 42 },
    ])
    setIsLoading(false)
  }, [router])

  const handleToggleDarkMode = () => {
    const newDarkMode = !isDarkMode
    setIsDarkMode(newDarkMode)
    localStorage.setItem("darkMode", String(newDarkMode))
    document.documentElement.classList.toggle("dark", newDarkMode)
  }

  if (isLoading) return null

  return (
    <main className="bg-background dark:bg-slate-950 min-h-screen">
      <Navigation isDarkMode={isDarkMode} onToggleDarkMode={handleToggleDarkMode} />

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Learning Path</h1>
          <p className="text-muted-foreground">Continue learning with your saved courses and progress</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <Link
              key={course.id}
              href={`/microcourse/${course.id}`}
              className="group p-6 rounded-lg border border-border dark:border-slate-700 hover:border-red-500 hover:shadow-lg dark:hover:shadow-red-500/20 smooth bg-background dark:bg-slate-900"
            >
              <div className="mb-4 inline-flex items-center justify-center w-12 h-12 rounded-lg bg-red-500/10 group-hover:bg-red-500 group-hover:text-white smooth">
                <BookOpen className="w-6 h-6" />
              </div>

              <h3 className="font-bold mb-2 line-clamp-2">{course.title}</h3>

              <div className="space-y-3">
                <div className="w-full bg-secondary dark:bg-slate-800 rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full smooth" style={{ width: `${course.progress}%` }} />
                </div>

                <div className="text-sm text-muted-foreground space-y-1">
                  <p>{course.progress}% complete</p>
                  <p>{course.duration} total</p>
                  <p>{course.enrolled} learners</p>
                </div>
              </div>

              <button className="mt-4 w-full py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 smooth">
                {course.progress === 100 ? "Completed" : "Continue"}
              </button>
            </Link>
          ))}
        </div>
      </div>
    </main>
  )
}
