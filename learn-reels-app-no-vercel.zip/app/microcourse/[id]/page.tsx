"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import Navigation from "@/components/navigation"
import { ArrowLeft, CheckCircle } from "lucide-react"

export default function MicrocoursePage() {
  const params = useParams()
  const router = useRouter()
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [currentReelIndex, setCurrentReelIndex] = useState(0)
  const [completedReels, setCompletedReels] = useState<number[]>([])

  const course = {
    id: params.id,
    title: "React Advanced Patterns",
    description: "Master advanced React patterns including HOCs, Render Props, and more.",
    creator: {
      name: "Sarah Chen",
      followers: "25K",
      avatar: "/diverse-avatars.png",
    },
    reels: [
      {
        id: 1,
        title: "Higher Order Components (HOCs)",
        description: "Learn how to create and use Higher Order Components to enhance React components.",
        thumbnail: "/react-logo-abstract.png",
        duration: "2:30",
      },
      {
        id: 2,
        title: "Render Props Pattern",
        description: "Master the render props pattern for sharing code between React components.",
        thumbnail: "/react-logo-abstract.png",
        duration: "2:15",
      },
      {
        id: 3,
        title: "Custom Hooks Deep Dive",
        description: "Create powerful custom hooks to manage complex component logic.",
        thumbnail: "/react-logo-abstract.png",
        duration: "3:00",
      },
    ],
  }

  useEffect(() => {
    const token = localStorage.getItem("authToken")
    if (!token) {
      router.push("/auth")
      return
    }

    const isDark = localStorage.getItem("darkMode") === "true"
    setIsDarkMode(isDark)
    document.documentElement.classList.toggle("dark", isDark)
    setIsLoading(false)
  }, [router])

  const handleToggleDarkMode = () => {
    const newDarkMode = !isDarkMode
    setIsDarkMode(newDarkMode)
    localStorage.setItem("darkMode", String(newDarkMode))
    document.documentElement.classList.toggle("dark", newDarkMode)
  }

  if (isLoading) return null

  const currentReel = course.reels[currentReelIndex]
  const progress = Math.round(((completedReels.length + 1) / course.reels.length) * 100)

  const handleCompleteReel = () => {
    if (!completedReels.includes(currentReelIndex)) {
      setCompletedReels([...completedReels, currentReelIndex])
    }
    if (currentReelIndex < course.reels.length - 1) {
      setCurrentReelIndex(currentReelIndex + 1)
    }
  }

  return (
    <main className="bg-background dark:bg-slate-950 min-h-screen">
      <Navigation isDarkMode={isDarkMode} onToggleDarkMode={handleToggleDarkMode} />

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/my-learning" className="p-2 hover:bg-secondary dark:hover:bg-slate-800 rounded-lg smooth">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <div>
            <h1 className="text-3xl font-bold">{course.title}</h1>
            <p className="text-muted-foreground">{course.reels.length} reels course</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Video */}
            <div className="aspect-video bg-black rounded-lg overflow-hidden mb-6">
              <Image
                src={currentReel.thumbnail || "/placeholder.svg"}
                alt={currentReel.title}
                width={700}
                height={400}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Reel Info */}
            <div className="space-y-4">
              <div>
                <h2 className="text-2xl font-bold mb-2">
                  Lesson {currentReelIndex + 1}: {currentReel.title}
                </h2>
                <p className="text-muted-foreground">{currentReel.description}</p>
              </div>

              {/* AI Summary */}
              <div className="p-4 bg-secondary/50 dark:bg-slate-800/50 rounded-lg border border-border dark:border-slate-700">
                <h3 className="font-semibold mb-3">Summary</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Higher Order Components (HOCs) are a pattern for reusing component logic. They take a component and
                  return an enhanced version with additional functionality, making it easy to share logic across
                  multiple components.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleCompleteReel}
                  className="flex-1 px-4 py-3 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 smooth flex items-center justify-center gap-2"
                >
                  <CheckCircle className="w-5 h-5" />
                  Mark as Complete
                </button>
                <Link
                  href={`/reel/${currentReel.id}`}
                  className="px-4 py-3 border border-border dark:border-slate-700 rounded-lg font-semibold hover:bg-secondary dark:hover:bg-slate-800 smooth"
                >
                  More Details
                </Link>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Course Progress */}
            <div className="p-6 rounded-lg border border-border dark:border-slate-700 bg-background dark:bg-slate-900 sticky top-20">
              <h3 className="font-bold mb-4">Your Progress</h3>
              <div className="mb-4">
                <p className="text-3xl font-bold text-red-500 mb-2">{progress}%</p>
                <div className="w-full bg-secondary dark:bg-slate-800 rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full smooth" style={{ width: `${progress}%` }} />
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                {completedReels.length + 1} of {course.reels.length} lessons completed
              </p>
            </div>

            {/* Lessons List */}
            <div className="p-6 rounded-lg border border-border dark:border-slate-700 bg-background dark:bg-slate-900">
              <h3 className="font-bold mb-4">Course Lessons</h3>
              <div className="space-y-2">
                {course.reels.map((reel, idx) => (
                  <button
                    key={reel.id}
                    onClick={() => setCurrentReelIndex(idx)}
                    className={`w-full text-left p-3 rounded-lg smooth ${
                      currentReelIndex === idx
                        ? "bg-red-500/10 border border-red-500 dark:bg-red-500/20"
                        : "border border-border dark:border-slate-700 hover:border-red-500"
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {completedReels.includes(idx) ? (
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      ) : (
                        <div
                          className={`w-5 h-5 rounded-full border-2 mt-0.5 flex-shrink-0 ${
                            currentReelIndex === idx ? "border-red-500" : "border-muted"
                          }`}
                        />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold line-clamp-1">Lesson {idx + 1}</p>
                        <p className="text-xs text-muted-foreground line-clamp-1">{reel.title}</p>
                      </div>
                      <span className="text-xs text-muted-foreground flex-shrink-0">{reel.duration}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Creator Info */}
            <div className="p-6 rounded-lg border border-border dark:border-slate-700 bg-background dark:bg-slate-900">
              <div className="flex items-center gap-3 mb-4">
                <Image
                  src={course.creator.avatar || "/placeholder.svg"}
                  alt={course.creator.name}
                  width={40}
                  height={40}
                  className="rounded-full"
                />
                <div>
                  <p className="font-semibold text-sm">{course.creator.name}</p>
                  <p className="text-xs text-muted-foreground">{course.creator.followers} followers</p>
                </div>
              </div>
              <button className="w-full px-4 py-2 border border-border dark:border-slate-700 rounded-lg font-semibold hover:bg-secondary dark:hover:bg-slate-800 smooth">
                Follow Creator
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
