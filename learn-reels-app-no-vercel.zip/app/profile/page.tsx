"use client"

import { useState, useEffect } from "react"
import Navigation from "@/components/navigation"
import Image from "next/image"
import { Edit2, MessageSquare, X } from "lucide-react"

export default function ProfilePage() {
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [activeTab, setActiveTab] = useState("profile")
  const [showChatbot, setShowChatbot] = useState(false)
  const [showEditProfile, setShowEditProfile] = useState(false)
  const [user, setUser] = useState({
    name: "Sarah Chen",
    username: "@sarahchen",
    bio: "Passionate about web development and teaching",
    avatar: "/diverse-avatars.png",
    followers: "25.5K",
    following: "342",
    posts: "128",
    email: "sarah@eduvexa.com",
  })
  const [editFormData, setEditFormData] = useState(user)

  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (currentUser) {
      const userData = JSON.parse(currentUser)
      setUser({
        name: userData.name,
        username: `@${userData.name.toLowerCase().replace(" ", "")}`,
        bio: "Passionate about web development and teaching",
        avatar: userData.avatar,
        followers: "25.5K",
        following: "342",
        posts: userData.reels || "0",
        email: userData.email,
      })
      setEditFormData({
        name: userData.name,
        username: `@${userData.name.toLowerCase().replace(" ", "")}`,
        bio: "Passionate about web development and teaching",
        avatar: userData.avatar,
        followers: "25.5K",
        following: "342",
        posts: userData.reels || "0",
        email: userData.email,
      })
    }

    const isDark = localStorage.getItem("darkMode") === "true"
    setIsDarkMode(isDark)
    if (isDark) {
      document.documentElement.classList.add("dark")
    }
  }, [])

  const handleToggleDarkMode = () => {
    const newDarkMode = !isDarkMode
    setIsDarkMode(newDarkMode)
    localStorage.setItem("darkMode", String(newDarkMode))
    if (newDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }

  const handleSaveProfile = () => {
    setUser(editFormData)
    const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
    currentUser.name = editFormData.name
    currentUser.bio = editFormData.bio || currentUser.bio
    localStorage.setItem("currentUser", JSON.stringify(currentUser))
    setShowEditProfile(false)
  }

  return (
    <main className="bg-background dark:bg-slate-950 min-h-screen">
      <Navigation isDarkMode={isDarkMode} onToggleDarkMode={handleToggleDarkMode} />

      <div className="max-w-2xl mx-auto px-4 py-12">
        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-border dark:border-slate-700">
          <button
            onClick={() => setActiveTab("profile")}
            className={`pb-3 px-2 font-semibold smooth ${
              activeTab === "profile" ? "border-b-2 border-red-500 text-red-500" : "text-muted-foreground"
            }`}
          >
            Profile
          </button>
          <button
            onClick={() => setActiveTab("settings")}
            className={`pb-3 px-2 font-semibold smooth ${
              activeTab === "settings" ? "border-b-2 border-red-500 text-red-500" : "text-muted-foreground"
            }`}
          >
            Settings
          </button>
        </div>

        {/* Profile Tab */}
        {activeTab === "profile" && (
          <>
            {/* Profile Header */}
            <div className="text-center mb-8">
              <Image
                src={user.avatar || "/placeholder.svg"}
                alt={user.name}
                width={120}
                height={120}
                className="rounded-full mx-auto mb-4 border-4 border-red-500"
              />
              <h1 className="text-3xl font-bold">{user.name}</h1>
              <p className="text-muted-foreground">{user.username}</p>
              <p className="text-sm text-foreground mt-2">{user.bio}</p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="p-6 rounded-lg border border-border dark:border-slate-700 bg-secondary/50 dark:bg-slate-800/50 text-center">
                <p className="text-2xl font-bold">{user.followers}</p>
                <p className="text-sm text-muted-foreground">Followers</p>
              </div>
              <div className="p-6 rounded-lg border border-border dark:border-slate-700 bg-secondary/50 dark:bg-slate-800/50 text-center">
                <p className="text-2xl font-bold">{user.following}</p>
                <p className="text-sm text-muted-foreground">Following</p>
              </div>
              <div className="p-6 rounded-lg border border-border dark:border-slate-700 bg-secondary/50 dark:bg-slate-800/50 text-center">
                <p className="text-2xl font-bold">{user.posts}</p>
                <p className="text-sm text-muted-foreground">Reels</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => {
                  setEditFormData(user)
                  setShowEditProfile(true)
                }}
                className="flex items-center gap-2 px-6 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 smooth"
              >
                <Edit2 className="w-4 h-4" />
                Edit Profile
              </button>
              <button
                onClick={() => setActiveTab("settings")}
                className="px-6 py-2 border border-border dark:border-slate-700 rounded-lg font-semibold hover:bg-secondary dark:hover:bg-slate-800 smooth"
              >
                Settings
              </button>
            </div>
          </>
        )}

        {/* Settings Tab */}
        {activeTab === "settings" && (
          <div className="space-y-6">
            {/* Account Settings */}
            <div className="p-6 border border-border dark:border-slate-700 rounded-lg space-y-4 bg-secondary/20 dark:bg-slate-800/30">
              <h2 className="text-lg font-semibold">Account</h2>
              <div className="space-y-3">
                <button className="w-full p-3 text-left rounded-lg border border-border dark:border-slate-700 hover:bg-secondary dark:hover:bg-slate-800 smooth">
                  Change Password
                </button>
                <button className="w-full p-3 text-left rounded-lg border border-border dark:border-slate-700 hover:bg-secondary dark:hover:bg-slate-800 smooth">
                  Email Preferences
                </button>
                <button className="w-full p-3 text-left rounded-lg border border-border dark:border-slate-700 hover:bg-secondary dark:hover:bg-slate-800 smooth">
                  Privacy Settings
                </button>
              </div>
            </div>

            <div className="p-6 border border-border dark:border-slate-700 rounded-lg space-y-4 bg-secondary/20 dark:bg-slate-800/30">
              <h2 className="text-lg font-semibold">Support</h2>
              <div className="space-y-3">
                <button
                  onClick={() => setShowChatbot(true)}
                  className="w-full p-3 text-left rounded-lg border border-border dark:border-slate-700 hover:bg-red-500/10 hover:border-red-500 smooth flex items-center gap-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  Chat with AI Assistant
                </button>
                <button className="w-full p-3 text-left rounded-lg border border-border dark:border-slate-700 hover:bg-secondary dark:hover:bg-slate-800 smooth">
                  FAQ
                </button>
                <button className="w-full p-3 text-left rounded-lg border border-border dark:border-slate-700 hover:bg-secondary dark:hover:bg-slate-800 smooth">
                  Contact Support
                </button>
              </div>
            </div>

            {/* Notifications */}
            <div className="p-6 border border-border dark:border-slate-700 rounded-lg space-y-4 bg-secondary/20 dark:bg-slate-800/30">
              <h2 className="text-lg font-semibold">Notifications</h2>
              <div className="space-y-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
                  <span>Email notifications for new followers</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
                  <span>Weekly learning digest</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" className="w-4 h-4 rounded" />
                  <span>Course recommendations</span>
                </label>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Edit Profile Modal */}
      {showEditProfile && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-background dark:bg-slate-900 rounded-lg max-w-md w-full shadow-lg border border-border dark:border-slate-700">
            {/* Header */}
            <div className="p-6 border-b border-border dark:border-slate-700 flex items-center justify-between">
              <h2 className="font-bold text-lg">Edit Profile</h2>
              <button onClick={() => setShowEditProfile(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Full Name</label>
                <input
                  type="text"
                  value={editFormData.name}
                  onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-border dark:border-slate-700 bg-background dark:bg-slate-800 text-foreground focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Bio</label>
                <textarea
                  value={editFormData.bio}
                  onChange={(e) => setEditFormData({ ...editFormData, bio: e.target.value })}
                  placeholder="Tell us about yourself"
                  className="w-full px-3 py-2 rounded-lg border border-border dark:border-slate-700 bg-background dark:bg-slate-800 text-foreground focus:outline-none focus:ring-2 focus:ring-red-500 resize-none h-24"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Email</label>
                <input
                  type="email"
                  value={editFormData.email}
                  disabled
                  className="w-full px-3 py-2 rounded-lg border border-border dark:border-slate-700 bg-secondary dark:bg-slate-800 text-muted-foreground cursor-not-allowed"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-border dark:border-slate-700 flex gap-3">
              <button
                onClick={() => setShowEditProfile(false)}
                className="flex-1 px-4 py-2 border border-border dark:border-slate-700 rounded-lg font-semibold hover:bg-secondary dark:hover:bg-slate-800 smooth"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveProfile}
                className="flex-1 px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 smooth"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {showChatbot && <AIChatbotModal onClose={() => setShowChatbot(false)} />}
    </main>
  )
}

interface AIChatbotModalProps {
  onClose: () => void
}

function AIChatbotModal({ onClose }: AIChatbotModalProps) {
  const [messages, setMessages] = useState([
    { type: "bot", text: "Hi! I'm the EduVexa AI Assistant. How can I help you today?" },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const commonQueries = [
    {
      q: "How do I upload a reel?",
      a: "To upload a reel, go to the Upload page and follow the form. You can add a video, title, description, tags, and difficulty level.",
    },
    {
      q: "How do I create a micro-course?",
      a: "In the Creator Dashboard, go to 'My Courses' and click 'Create New Course'. Add multiple reels to build your course structure.",
    },
    {
      q: "Can I download my videos?",
      a: "Videos are streamed directly from EduVexa. You can share them using the Share button on each reel.",
    },
    {
      q: "How do I reset my password?",
      a: "Go to Profile → Settings → Account → Change Password. You'll receive an email with reset instructions.",
    },
  ]

  const handleSendMessage = () => {
    if (!input.trim()) return

    setMessages((prev) => [...prev, { type: "user", text: input }])
    setIsLoading(true)
    setInput("")

    setTimeout(() => {
      const response = commonQueries.find((q) => q.q.toLowerCase().includes(input.toLowerCase())) || {
        a: "I'm not sure about that. Please contact our support team for more help.",
      }
      setMessages((prev) => [...prev, { type: "bot", text: response.a }])
      setIsLoading(false)
    }, 800)
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-background dark:bg-slate-900 rounded-lg w-full max-w-md max-h-96 flex flex-col shadow-lg border border-border dark:border-slate-700">
        {/* Header */}
        <div className="p-4 border-b border-border dark:border-slate-700 flex items-center justify-between">
          <h2 className="font-bold text-lg">EduVexa AI Assistant</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-xs px-4 py-2 rounded-lg ${
                  msg.type === "user" ? "bg-red-500 text-white" : "bg-secondary dark:bg-slate-800 text-foreground"
                }`}
              >
                <p className="text-sm">{msg.text}</p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-secondary dark:bg-slate-800 px-4 py-2 rounded-lg">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                  <div
                    className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  />
                  <div
                    className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="p-4 border-t border-border dark:border-slate-700 space-y-3">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              placeholder="Ask a question..."
              className="flex-1 px-3 py-2 rounded-lg border border-border dark:border-slate-700 bg-secondary dark:bg-slate-800 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-red-500"
            />
            <button
              onClick={handleSendMessage}
              disabled={isLoading}
              className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 smooth disabled:opacity-50"
            >
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
