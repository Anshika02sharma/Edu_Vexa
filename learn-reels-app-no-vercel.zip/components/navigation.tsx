"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { Menu, X, Moon, Sun, LogOut } from "lucide-react"

interface NavigationProps {
  isDarkMode: boolean
  onToggleDarkMode: () => void
}

export default function Navigation({ isDarkMode, onToggleDarkMode }: NavigationProps) {
  const router = useRouter()
  const [isOpen, setIsOpen] = useState(false)
  const [showProfileMenu, setShowProfileMenu] = useState(false)

  const handleLogout = () => {
    localStorage.removeItem("authToken")
    localStorage.removeItem("currentUser")
    router.push("/auth")
  }

  return (
    <nav className="sticky top-0 z-50 border-b bg-background dark:bg-slate-950 border-border dark:border-slate-700 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold bg-red-500">
              EV
            </div>
            <span className="hidden sm:inline">EduVexa</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="/" className="hover:opacity-70 smooth">
              Home
            </Link>
            <Link href="/my-learning" className="hover:opacity-70 smooth">
              My Learning
            </Link>
            <Link href="/upload" className="hover:opacity-70 smooth">
              Upload
            </Link>
            <Link href="/creator" className="hover:opacity-70 smooth">
              Creator
            </Link>
            <Link href="/profile" className="hover:opacity-70 smooth">
              Profile
            </Link>
          </div>

          {/* Dark Mode Toggle & Mobile Menu */}
          <div className="flex items-center gap-4">
            <button
              onClick={onToggleDarkMode}
              className="p-2 rounded-lg hover:bg-secondary dark:hover:bg-slate-800 smooth"
              aria-label="Toggle dark mode"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            <div className="relative hidden md:block">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="p-2 rounded-lg hover:bg-secondary dark:hover:bg-slate-800 smooth"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 12a3 3 0 100-6 3 3 0 000 6z" />
                  <path
                    fillRule="evenodd"
                    d="M12 18a9 9 0 100-18 9 9 0 000 18zm0-2a7 7 0 100-14 7 7 0 000 14z"
                    clipRule="evenodd"
                  />
                </svg>
              </button>

              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-48 rounded-lg bg-background dark:bg-slate-900 border border-border dark:border-slate-700 shadow-lg overflow-hidden z-50">
                  <Link href="/profile" className="block px-4 py-2 hover:bg-secondary dark:hover:bg-slate-800 text-sm">
                    Profile Settings
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 hover:bg-secondary dark:hover:bg-slate-800 text-sm flex items-center gap-2 text-red-500"
                  >
                    <LogOut className="w-4 h-4" />
                    Logout
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-secondary dark:hover:bg-slate-800"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden pb-4 space-y-3 border-t border-border dark:border-slate-700 pt-4">
            <Link href="/" className="block px-3 py-2 rounded-lg hover:bg-secondary dark:hover:bg-slate-800 smooth">
              Home
            </Link>
            <Link
              href="/my-learning"
              className="block px-3 py-2 rounded-lg hover:bg-secondary dark:hover:bg-slate-800 smooth"
            >
              My Learning
            </Link>
            <Link
              href="/upload"
              className="block px-3 py-2 rounded-lg hover:bg-secondary dark:hover:bg-slate-800 smooth"
            >
              Upload Reel
            </Link>
            <Link
              href="/creator"
              className="block px-3 py-2 rounded-lg hover:bg-secondary dark:hover:bg-slate-800 smooth"
            >
              Creator Dashboard
            </Link>
            <Link
              href="/profile"
              className="block px-3 py-2 rounded-lg hover:bg-secondary dark:hover:bg-slate-800 smooth"
            >
              Profile
            </Link>
            <button
              onClick={handleLogout}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-secondary dark:hover:bg-slate-800 smooth flex items-center gap-2 text-red-500 text-sm"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        )}
      </div>
    </nav>
  )
}
