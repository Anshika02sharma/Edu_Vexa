"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Heart, MessageCircle, Share2, Bookmark, Play } from "lucide-react"

interface ReelCardProps {
  reel: any
  index: number
}

export default function ReelCard({ reel, index }: ReelCardProps) {
  const [isLiked, setIsLiked] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const [likes, setLikes] = useState(reel.likes)

  const handleLike = () => {
    setIsLiked(!isLiked)
    setLikes(isLiked ? likes - 1 : likes + 1)
  }

  const handleSave = () => {
    setIsSaved(!isSaved)
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: reel.title,
        text: `Check out this learning reel on EduVexa`,
        url: window.location.href,
      })
    }
  }

  return (
    <Link href={`/reel/${reel.id}`}>
      <div className="h-screen w-full bg-black relative overflow-hidden flex items-center justify-center snap-start cursor-pointer">
        {/* Background Video/Image */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 to-black">
          <div className="absolute inset-0 bg-black/40" />
        </div>

        {/* Video Thumbnail */}
        <div className="relative w-full h-full flex items-center justify-center">
          <Image
            src={reel.thumbnail || "/placeholder.svg"}
            alt={reel.title}
            fill
            className="object-cover"
            quality={85}
          />

          {/* Play Button Overlay */}
          <div className="absolute inset-0 flex items-center justify-center group cursor-pointer hover:bg-black/20 smooth">
            <div className="bg-white/20 group-hover:bg-white/30 smooth rounded-full p-4 backdrop-blur-sm">
              <Play className="w-12 h-12 text-white fill-white" />
            </div>
          </div>

          {/* Content Overlay - Bottom */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/50 to-transparent p-6 text-white">
            <div className="max-w-sm">
              {/* Creator Info */}
              <div className="flex items-center gap-3 mb-4">
                <Image
                  src={reel.creator.avatar || "/placeholder.svg"}
                  alt={reel.creator.name}
                  width={40}
                  height={40}
                  className="rounded-full"
                />
                <div>
                  <p className="font-semibold">{reel.creator.name}</p>
                  <p className="text-xs text-gray-300">{reel.creator.followers} followers</p>
                </div>
              </div>

              {/* Title & Description */}
              <h2 className="text-xl font-bold mb-2 line-clamp-2">{reel.title}</h2>
              <p className="text-sm text-gray-200 mb-3 line-clamp-2">{reel.description}</p>

              {/* Tags & Difficulty */}
              <div className="flex flex-wrap gap-2 mb-4">
                {reel.tags.slice(0, 2).map((tag, i) => (
                  <span key={i} className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs">
                    {tag}
                  </span>
                ))}
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    reel.difficulty === "Beginner"
                      ? "bg-green-500/30"
                      : reel.difficulty === "Intermediate"
                        ? "bg-yellow-500/30"
                        : "bg-red-500/30"
                  }`}
                >
                  {reel.difficulty}
                </span>
              </div>

              {/* Duration & Views */}
              <p className="text-xs text-gray-300">
                {reel.duration} • {reel.views} views
              </p>
            </div>
          </div>

          {/* Action Buttons - Right Side */}
          <div className="absolute right-6 bottom-20 flex flex-col gap-4 z-10">
            <button
              onClick={(e) => {
                e.preventDefault()
                handleLike()
              }}
              className={`flex flex-col items-center gap-1 smooth ${isLiked ? "text-red-500" : "text-white hover:text-red-500"}`}
            >
              <Heart className="w-7 h-7" fill={isLiked ? "currentColor" : "none"} />
              <span className="text-xs font-semibold">{likes}</span>
            </button>

            <button
              onClick={(e) => {
                e.preventDefault()
              }}
              className="flex flex-col items-center gap-1 text-white hover:text-blue-400 smooth"
            >
              <MessageCircle className="w-7 h-7" />
              <span className="text-xs font-semibold">{reel.comments}</span>
            </button>

            <button
              onClick={(e) => {
                e.preventDefault()
                handleShare()
              }}
              className="flex flex-col items-center gap-1 text-white hover:text-green-400 smooth"
            >
              <Share2 className="w-7 h-7" />
              <span className="text-xs">Share</span>
            </button>

            <button
              onClick={(e) => {
                e.preventDefault()
                handleSave()
              }}
              className={`flex flex-col items-center gap-1 smooth ${isSaved ? "text-yellow-400" : "text-white hover:text-yellow-400"}`}
            >
              <Bookmark className="w-7 h-7" fill={isSaved ? "currentColor" : "none"} />
              <span className="text-xs">Save</span>
            </button>
          </div>
        </div>

        {/* Index Indicator */}
        <div className="absolute top-6 left-6 text-white/60 text-sm font-mono">
          {String(index + 1).padStart(2, "0")}
        </div>
      </div>
    </Link>
  )
}
