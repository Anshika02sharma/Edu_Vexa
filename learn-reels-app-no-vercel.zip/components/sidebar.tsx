"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowRight, Clock, BookOpen } from "lucide-react"

export default function Sidebar() {
  const [recommendedTopics] = useState([
    { id: 1, name: "Web Development", count: 24 },
    { id: 2, name: "Data Science", count: 18 },
    { id: 3, name: "Mobile Apps", count: 15 },
    { id: 4, name: "AI & ML", count: 32 },
    { id: 5, name: "Design", count: 12 },
  ])

  const [continueLearning] = useState([
    { id: 1, title: "React Hooks Advanced", progress: 65 },
    { id: 2, title: "TypeScript Basics", progress: 40 },
    { id: 3, title: "Next.js 15 Features", progress: 85 },
  ])

  return (
    <aside className="w-full h-screen overflow-y-auto sticky top-16 p-6 space-y-8">
      {/* Recommended Topics */}
      <div>
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5" />
          Recommended Topics
        </h3>
        <div className="space-y-2">
          {recommendedTopics.map((topic) => (
            <Link
              key={topic.id}
              href={`/?topic=${topic.id}`}
              className="flex items-center justify-between p-3 rounded-lg hover:bg-primary/10 smooth group"
            >
              <div>
                <p className="font-medium text-sm">{topic.name}</p>
                <p className="text-xs text-muted-foreground">{topic.count} reels</p>
              </div>
              <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 smooth" />
            </Link>
          ))}
        </div>
      </div>

      {/* Continue Learning */}
      <div>
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Continue Learning
        </h3>
        <div className="space-y-3">
          {continueLearning.map((course) => (
            <Link
              key={course.id}
              href={`/microcourse/${course.id}`}
              className="block p-4 rounded-lg border border-border hover:border-accent smooth"
            >
              <p className="font-medium text-sm mb-2 line-clamp-1">{course.title}</p>
              <div className="w-full bg-secondary rounded-full h-1.5">
                <div className="bg-accent h-1.5 rounded-full smooth" style={{ width: `${course.progress}%` }} />
              </div>
              <p className="text-xs text-muted-foreground mt-2">{course.progress}% complete</p>
            </Link>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="p-4 rounded-lg bg-secondary/50 border border-border">
        <p className="text-xs text-muted-foreground mb-3">This Week</p>
        <div className="space-y-2">
          <p className="text-sm font-semibold">12 reels watched</p>
          <p className="text-sm font-semibold">45 min learning</p>
          <p className="text-sm font-semibold">3 courses ongoing</p>
        </div>
      </div>
    </aside>
  )
}
