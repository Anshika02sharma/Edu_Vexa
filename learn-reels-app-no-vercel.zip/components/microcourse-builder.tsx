"use client"

import { useState } from "react"
import { Plus, Trash2, GripVertical } from "lucide-react"

export default function MicrocourseBuilder() {
  const [courses, setCourses] = useState([
    {
      id: 1,
      title: "React Advanced Patterns",
      reels: [
        { id: 1, title: "Higher Order Components", duration: "2:30" },
        { id: 2, title: "Render Props Pattern", duration: "2:15" },
      ],
    },
  ])

  const [showNewCourse, setShowNewCourse] = useState(false)
  const [newTitle, setNewTitle] = useState("")

  const handleCreateCourse = () => {
    if (newTitle.trim()) {
      setCourses([...courses, { id: courses.length + 1, title: newTitle, reels: [] }])
      setNewTitle("")
      setShowNewCourse(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Create New Course */}
      {!showNewCourse ? (
        <button
          onClick={() => setShowNewCourse(true)}
          className="w-full p-6 border-2 border-dashed border-border rounded-lg hover:border-accent smooth flex items-center justify-center gap-2 text-accent font-semibold"
        >
          <Plus className="w-5 h-5" />
          Create New Micro-course
        </button>
      ) : (
        <div className="p-6 border border-border rounded-lg bg-secondary/50 space-y-4">
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="Enter course title..."
            className="w-full px-4 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-accent"
            autoFocus
          />
          <div className="flex gap-2">
            <button
              onClick={handleCreateCourse}
              className="flex-1 px-4 py-2 bg-accent text-white rounded-lg font-semibold hover:bg-accent/90 smooth"
            >
              Create
            </button>
            <button
              onClick={() => {
                setShowNewCourse(false)
                setNewTitle("")
              }}
              className="flex-1 px-4 py-2 border border-border rounded-lg hover:bg-secondary smooth"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Courses List */}
      {courses.map((course) => (
        <div key={course.id} className="p-6 border border-border rounded-lg">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="font-bold text-lg">{course.title}</h3>
              <p className="text-sm text-muted-foreground">{course.reels.length} reels</p>
            </div>
            <button className="p-2 text-destructive hover:bg-destructive/10 rounded-lg smooth">
              <Trash2 className="w-5 h-5" />
            </button>
          </div>

          {/* Reels List */}
          <div className="space-y-2">
            {course.reels.map((reel, idx) => (
              <div key={reel.id} className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
                <GripVertical className="w-4 h-4 text-muted-foreground" />
                <div className="flex-1">
                  <p className="text-sm font-semibold">
                    {idx + 1}. {reel.title}
                  </p>
                  <p className="text-xs text-muted-foreground">{reel.duration}</p>
                </div>
                <button className="p-1 hover:bg-destructive/10 rounded text-destructive">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
            <button className="w-full p-3 border-2 border-dashed border-border rounded-lg text-sm font-semibold hover:border-accent smooth text-muted-foreground hover:text-accent">
              + Add Reel to Course
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}
