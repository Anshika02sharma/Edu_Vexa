"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, Volume2, VolumeX } from "lucide-react"

interface ReelPlayerProps {
  reel: any
  autoplayWithSound?: boolean
}

let currentPlayingVideoRef: HTMLVideoElement | null = null

export default function ReelPlayer({ reel, autoplayWithSound = false }: ReelPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(autoplayWithSound)
  const [isMuted, setIsMuted] = useState(!autoplayWithSound)
  const [currentTime, setCurrentTime] = useState(0)
  const [showPlayOverlay, setShowPlayOverlay] = useState(!autoplayWithSound)
  const [volume, setVolume] = useState(1)
  const videoRef = useRef<HTMLVideoElement>(null)
  const playPromiseRef = useRef<Promise<void> | null>(null)

  const safePlay = async () => {
    if (!videoRef.current) return
    try {
      const playPromise = videoRef.current.play()
      playPromiseRef.current = playPromise
      await playPromise
      setIsPlaying(true)
      setShowPlayOverlay(false)
    } catch (error: any) {
      if (error.name !== "AbortError" && error.name !== "NotAllowedError") {
        console.error("Play error:", error)
      }
      setShowPlayOverlay(true)
      setIsPlaying(false)
    }
  }

  const safePause = () => {
    if (!videoRef.current) return
    try {
      videoRef.current.pause()
      setIsPlaying(false)
    } catch (error) {
      console.error("Pause error:", error)
    }
  }

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    if (autoplayWithSound) {
      if (currentPlayingVideoRef && currentPlayingVideoRef !== video) {
        currentPlayingVideoRef.pause()
        currentPlayingVideoRef.muted = true
      }

      currentPlayingVideoRef = video
      video.muted = false
      setIsMuted(false)

      safePlay().catch(() => {
        setShowPlayOverlay(true)
        setIsPlaying(false)
      })
    }

    return () => {
      if (video === currentPlayingVideoRef) {
        currentPlayingVideoRef = null
      }
    }
  }, [autoplayWithSound, reel.id])

  const handlePlayPause = async () => {
    if (!videoRef.current) return

    if (isPlaying) {
      safePause()
    } else {
      if (currentPlayingVideoRef && currentPlayingVideoRef !== videoRef.current) {
        currentPlayingVideoRef.pause()
        currentPlayingVideoRef.muted = true
      }
      currentPlayingVideoRef = videoRef.current

      await safePlay()
    }
  }

  const handleMute = () => {
    if (!videoRef.current) return
    const newMuted = !isMuted
    setIsMuted(newMuted)
    videoRef.current.muted = newMuted
  }

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = Number.parseFloat(e.target.value)
    setVolume(newVolume)
    if (videoRef.current) {
      videoRef.current.volume = newVolume
      if (newVolume > 0) {
        videoRef.current.muted = false
        setIsMuted(false)
      }
    }
  }

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const updateTime = () => setCurrentTime(video.currentTime)
    video.addEventListener("timeupdate", updateTime)
    video.addEventListener("ended", () => {
      setIsPlaying(false)
      setCurrentTime(0)
    })

    return () => {
      video.removeEventListener("timeupdate", updateTime)
      video.removeEventListener("ended", () => {})
    }
  }, [])

  const duration = reel.duration
    ? Number.parseInt(reel.duration.split(":")[0]) * 60 + Number.parseInt(reel.duration.split(":")[1])
    : 0
  const progress = duration ? (currentTime / duration) * 100 : 0

  return (
    <div className="relative aspect-video bg-black rounded-lg overflow-hidden group">
      <video
        ref={videoRef}
        src={reel.videoUrl || "https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4"}
        poster={reel.thumbnail || "/placeholder.svg"}
        className="w-full h-full object-cover"
        loop
        controlsList="nodownload"
      />

      {/* Play Overlay - Tap to Play with Sound */}
      {showPlayOverlay && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 z-20">
          <button
            onClick={handlePlayPause}
            className="bg-white text-black rounded-full p-6 hover:scale-110 smooth shadow-lg"
          >
            <Play className="w-8 h-8 fill-current" />
          </button>
          <div className="absolute bottom-4 left-4 bg-black/70 px-3 py-2 rounded-lg text-white text-sm">
            Tap to Play with Sound
          </div>
        </div>
      )}

      {/* Controls Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 smooth flex flex-col justify-between p-4">
        {/* Play/Pause Button */}
        <div className="flex items-center justify-center flex-1">
          <button
            onClick={handlePlayPause}
            className="bg-white/20 hover:bg-white/40 smooth rounded-full p-4 backdrop-blur-sm"
          >
            {isPlaying ? <Pause className="w-8 h-8 text-white" /> : <Play className="w-8 h-8 text-white fill-white" />}
          </button>
        </div>

        {/* Progress Bar & Controls */}
        <div className="space-y-2">
          <div className="w-full bg-white/20 rounded-full h-1">
            <div className="bg-red-500 h-1 rounded-full smooth" style={{ width: `${progress}%` }} />
          </div>

          {/* Time & Volume Controls */}
          <div className="flex items-center justify-between">
            <span className="text-xs text-white font-mono">
              {Math.floor(currentTime)}s / {duration}s
            </span>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={volume}
                onChange={handleVolumeChange}
                className="w-20 h-1 rounded-full cursor-pointer accent-white"
              />
              <button onClick={handleMute} className="p-2 hover:bg-white/20 smooth rounded-lg">
                {isMuted ? <VolumeX className="w-4 h-4 text-white" /> : <Volume2 className="w-4 h-4 text-white" />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
