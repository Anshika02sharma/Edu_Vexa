"use client"

import { useState } from "react"
import { X, CheckCircle, XCircle } from "lucide-react"
import { mockQuizzes } from "@/lib/mock-data"

interface QuizModalProps {
  reelId: string | string[]
  onClose: () => void
}

export default function QuizModal({ reelId, onClose }: QuizModalProps) {
  const quiz = mockQuizzes.find((q) => q.reelId === reelId) || mockQuizzes[0]
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [score, setScore] = useState(0)
  const [answered, setAnswered] = useState<{ [key: number]: number }>({})
  const [showResults, setShowResults] = useState(false)

  const question = quiz.questions[currentQuestion]
  const userAnswer = answered[currentQuestion]
  const isCorrect = userAnswer === question.correctAnswer

  const handleAnswer = (optionIndex: number) => {
    if (!answered[currentQuestion]) {
      setAnswered((prev) => ({
        ...prev,
        [currentQuestion]: optionIndex,
      }))

      if (optionIndex === question.correctAnswer) {
        setScore(score + 1)
      }
    }
  }

  const handleNext = () => {
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setShowResults(true)
    }
  }

  const percentage = Math.round((score / quiz.questions.length) * 100)

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-background dark:bg-slate-900 rounded-lg max-w-2xl w-full max-h-96 overflow-y-auto border border-border dark:border-slate-700">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border dark:border-slate-700 sticky top-0 bg-background dark:bg-slate-900">
          <h2 className="font-bold text-lg">Practice Quiz</h2>
          <button onClick={onClose} className="p-2 hover:bg-secondary dark:hover:bg-slate-800 rounded-lg smooth">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {!showResults ? (
            <>
              {/* Progress */}
              <div className="mb-6">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-semibold">
                    Question {currentQuestion + 1}/{quiz.questions.length}
                  </span>
                  <span className="text-sm text-muted-foreground">{score} correct</span>
                </div>
                <div className="w-full bg-secondary dark:bg-slate-800 rounded-full h-1.5">
                  <div
                    className="bg-red-500 h-1.5 rounded-full smooth"
                    style={{ width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%` }}
                  />
                </div>
              </div>

              {/* Question */}
              <h3 className="text-lg font-semibold mb-6">{question.question}</h3>

              {/* Options */}
              <div className="space-y-3 mb-6">
                {question.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswer(index)}
                    disabled={answered[currentQuestion] !== undefined}
                    className={`w-full p-4 rounded-lg border-2 text-left smooth ${
                      userAnswer === index
                        ? isCorrect
                          ? "bg-green-500/10 border-green-500"
                          : "bg-red-500/10 border-red-500"
                        : answered[currentQuestion] !== undefined && index === question.correctAnswer
                          ? "bg-green-500/10 border-green-500"
                          : "border-border dark:border-slate-700 hover:border-red-500 disabled:opacity-50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {userAnswer === index &&
                        (isCorrect ? (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        ) : (
                          <XCircle className="w-5 h-5 text-red-500" />
                        ))}
                      {answered[currentQuestion] !== undefined &&
                        index === question.correctAnswer &&
                        userAnswer !== index && <CheckCircle className="w-5 h-5 text-green-500" />}
                      <span>{option}</span>
                    </div>
                  </button>
                ))}
              </div>

              {/* Explanation */}
              {answered[currentQuestion] !== undefined && (
                <div className="p-4 bg-secondary/50 dark:bg-slate-800/50 rounded-lg mb-6 border border-border dark:border-slate-700">
                  <p className="text-sm font-semibold mb-2">Explanation</p>
                  <p className="text-sm text-muted-foreground">{question.explanation}</p>
                </div>
              )}

              {/* Next Button */}
              {answered[currentQuestion] !== undefined && (
                <button
                  onClick={handleNext}
                  className="w-full px-4 py-3 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 smooth"
                >
                  {currentQuestion === quiz.questions.length - 1 ? "See Results" : "Next Question"}
                </button>
              )}
            </>
          ) : (
            <>
              {/* Results */}
              <div className="text-center space-y-6">
                <div>
                  <p className="text-5xl font-bold text-red-500 mb-2">{percentage}%</p>
                  <p className="text-lg font-semibold">
                    {percentage >= 80
                      ? "Excellent! Great understanding of the concepts."
                      : percentage >= 60
                        ? "Good job! Review the topics you missed."
                        : "Keep practicing! Review the material and try again."}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4 p-4 bg-secondary/50 dark:bg-slate-800/50 rounded-lg">
                  <div>
                    <p className="text-xs text-muted-foreground">Score</p>
                    <p className="font-bold text-lg">
                      {score}/{quiz.questions.length}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Accuracy</p>
                    <p className="font-bold text-lg">{percentage}%</p>
                  </div>
                </div>

                <button
                  onClick={onClose}
                  className="w-full px-4 py-3 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 smooth"
                >
                  Close
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
