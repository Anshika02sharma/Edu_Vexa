"use client"

import { useState } from "react"
import { Upload, Plus, BarChart3 } from "lucide-react"
import UploadReelForm from "./upload-reel-form"
import CreatorAnalytics from "./creator-analytics"
import MicrocourseBuilder from "./microcourse-builder"

type Tab = "upload" | "courses" | "analytics"

export default function CreatorDashboard() {
  const [activeTab, setActiveTab] = useState<Tab>("upload")

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Creator Dashboard</h1>
        <p className="text-muted-foreground">Manage your reels, courses, and track engagement</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 border-b border-border">
        <button
          onClick={() => setActiveTab("upload")}
          className={`px-4 py-3 font-semibold border-b-2 smooth ${
            activeTab === "upload"
              ? "border-accent text-accent"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          <Upload className="inline-block w-4 h-4 mr-2" />
          Upload Reel
        </button>
        <button
          onClick={() => setActiveTab("courses")}
          className={`px-4 py-3 font-semibold border-b-2 smooth ${
            activeTab === "courses"
              ? "border-accent text-accent"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          <Plus className="inline-block w-4 h-4 mr-2" />
          My Courses
        </button>
        <button
          onClick={() => setActiveTab("analytics")}
          className={`px-4 py-3 font-semibold border-b-2 smooth ${
            activeTab === "analytics"
              ? "border-accent text-accent"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          <BarChart3 className="inline-block w-4 h-4 mr-2" />
          Analytics
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === "upload" && <UploadReelForm />}
      {activeTab === "courses" && <MicrocourseBuilder />}
      {activeTab === "analytics" && <CreatorAnalytics />}
    </div>
  )
}
