"use client"

import { useState, useEffect } from "react"
import ReelCard from "./reel-card"
import { mockReels } from "@/lib/mock-data"

export default function ReelFeed() {
  const [reels, setReels] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      setReels(mockReels)
      setIsLoading(false)
    }, 300)
    return () => clearTimeout(timer)
  }, [])

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent"></div>
      </div>
    )
  }

  return (
    <div className="space-y-0 max-h-screen overflow-y-auto snap-y snap-mandatory scrollbar-hide">
      {reels.map((reel, index) => (
        <div key={reel.id} className="snap-start">
          <ReelCard reel={reel} index={index} />
        </div>
      ))}
    </div>
  )
}
