"use client"

import { useState } from "react"
import Image from "next/image"
import { Send } from "lucide-react"

interface CommentSectionProps {
  reelId: string | string[]
}

export default function CommentSection({ reelId }: CommentSectionProps) {
  const [comments, setComments] = useState([
    {
      id: 1,
      author: "Sarah Chen",
      avatar: "/diverse-avatars.png",
      text: "This is incredibly helpful! Finally understand React hooks.",
      time: "2h ago",
      likes: 12,
    },
    {
      id: 2,
      author: "John Dev",
      avatar: "/diverse-avatars.png",
      text: "Can you do a follow-up on custom hooks?",
      time: "1h ago",
      likes: 5,
    },
  ])

  const [newComment, setNewComment] = useState("")

  const handleAddComment = () => {
    if (newComment.trim()) {
      setComments([
        {
          id: comments.length + 1,
          author: "You",
          avatar: "/diverse-avatars.png",
          text: newComment,
          time: "now",
          likes: 0,
        },
        ...comments,
      ])
      setNewComment("")
    }
  }

  return (
    <div className="space-y-4">
      <h3 className="font-bold text-sm">Comments</h3>

      {/* Comment Input */}
      <div className="flex gap-2">
        <input
          type="text"
          placeholder="Add a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleAddComment()}
          className="flex-1 px-3 py-2 rounded-lg bg-secondary dark:bg-slate-800 border border-border dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
        />
        <button onClick={handleAddComment} className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 smooth">
          <Send className="w-4 h-4" />
        </button>
      </div>

      {/* Comments List */}
      <div className="space-y-3 max-h-64 overflow-y-auto">
        {comments.map((comment) => (
          <div key={comment.id} className="p-3 rounded-lg bg-secondary/50 dark:bg-slate-800/50 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Image
                  src={comment.avatar || "/placeholder.svg"}
                  alt={comment.author}
                  width={28}
                  height={28}
                  className="rounded-full"
                />
                <div>
                  <p className="text-xs font-semibold">{comment.author}</p>
                  <p className="text-xs text-muted-foreground">{comment.time}</p>
                </div>
              </div>
            </div>
            <p className="text-xs text-foreground">{comment.text}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
