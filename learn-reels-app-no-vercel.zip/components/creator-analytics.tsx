"use client"

import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const viewsData = [
  { day: "Mon", views: 240 },
  { day: "Tue", views: 320 },
  { day: "Wed", views: 280 },
  { day: "Thu", views: 420 },
  { day: "Fri", views: 550 },
  { day: "Sat", views: 480 },
  { day: "Sun", views: 390 },
]

const engagementData = [
  { reel: "React Hooks", likes: 240, saves: 180, comments: 65 },
  { reel: "TypeScript Tips", likes: 190, saves: 140, comments: 45 },
  { reel: "Next.js SEO", likes: 320, saves: 220, comments: 85 },
  { reel: "CSS Grid", likes: 280, saves: 200, comments: 72 },
]

export default function CreatorAnalytics() {
  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-6 rounded-lg border border-border bg-secondary/50">
          <p className="text-sm text-muted-foreground mb-2">Total Views</p>
          <p className="text-3xl font-bold">24.5K</p>
          <p className="text-xs text-green-600 mt-2">+12% this week</p>
        </div>
        <div className="p-6 rounded-lg border border-border bg-secondary/50">
          <p className="text-sm text-muted-foreground mb-2">Total Likes</p>
          <p className="text-3xl font-bold">3.2K</p>
          <p className="text-xs text-green-600 mt-2">+8% this week</p>
        </div>
        <div className="p-6 rounded-lg border border-border bg-secondary/50">
          <p className="text-sm text-muted-foreground mb-2">Saves</p>
          <p className="text-3xl font-bold">1.8K</p>
          <p className="text-xs text-green-600 mt-2">+15% this week</p>
        </div>
        <div className="p-6 rounded-lg border border-border bg-secondary/50">
          <p className="text-sm text-muted-foreground mb-2">Avg Watch Time</p>
          <p className="text-3xl font-bold">58s</p>
          <p className="text-xs text-yellow-600 mt-2">of 90s duration</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-6 rounded-lg border border-border bg-secondary/30">
          <h3 className="font-bold mb-4">Views Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={viewsData}>
              <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="3 3" />
              <XAxis stroke="hsl(var(--muted-foreground))" style={{ fontSize: "12px" }} />
              <YAxis stroke="hsl(var(--muted-foreground))" style={{ fontSize: "12px" }} />
              <Tooltip />
              <Line type="monotone" dataKey="views" stroke="hsl(var(--accent))" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="p-6 rounded-lg border border-border bg-secondary/30">
          <h3 className="font-bold mb-4">Engagement by Reel</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={engagementData}>
              <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="3 3" />
              <XAxis stroke="hsl(var(--muted-foreground))" style={{ fontSize: "12px" }} />
              <YAxis stroke="hsl(var(--muted-foreground))" style={{ fontSize: "12px" }} />
              <Tooltip />
              <Bar dataKey="likes" fill="hsl(var(--accent))" />
              <Bar dataKey="saves" fill="hsl(var(--chart-3))" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top Reels */}
      <div className="p-6 rounded-lg border border-border bg-secondary/30">
        <h3 className="font-bold mb-4">Top Performing Reels</h3>
        <div className="space-y-3">
          {engagementData.map((item, i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-background/50">
              <p className="font-semibold text-sm">{item.reel}</p>
              <div className="flex gap-6 text-sm">
                <span className="text-muted-foreground">{item.likes} likes</span>
                <span className="text-muted-foreground">{item.saves} saves</span>
                <span className="text-muted-foreground">{item.comments} comments</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
