# Quick Start Guide - EduVexa

Get EduVexa running in 5 minutes!

## Step 1: Installation
\`\`\`bash
npm install
npm run dev
\`\`\`

Visit `http://localhost:3000`

## Step 2: Login
Use demo credentials:
- Email: `demo@eduvexa.com`
- Password: `demo123`

Or create a new account by clicking "Sign Up"

## Step 3: Explore Features

### 1. Watch Reels
- Scroll down on home feed to watch learning videos
- Click any reel to open full player
- Use controls: play, pause, volume, mute

### 2. Take Quiz
- On reel detail page, click "Practice Quiz"
- Answer 5 multiple-choice questions
- See instant feedback and score

### 3. Edit Profile
- Click Profile in navigation
- Click "Edit Profile" button
- Update name and bio
- Click "Save Changes"

### 4. Dark Mode
- Click moon icon in navbar
- Choose between light (creme) and dark (slate) themes
- Preference saved automatically

### 5. Upload Reel (Creator)
- Click "Upload" in navigation
- Fill in title, description, tags, difficulty
- Click "Upload Reel"
- Your reel appears in feed

### 6. Get Help
- Go to Profile → Settings → Chat with AI
- Ask common questions
- Get instant answers

### 7. My Learning
- Click "My Learning" to see saved courses
- Track progress with visual progress bars
- Continue courses you started

## Important Notes

✅ All features work offline using localStorage
✅ Demo video plays for all reels
✅ Create multiple accounts to test
✅ Dark/light theme persists across sessions
✅ Profile edits save automatically

## Video Player Controls

| Control | Action |
|---------|--------|
| Play/Pause | Click center button or video |
| Volume | Drag slider 0-100% |
| Mute | Click speaker icon |
| Progress | Drag timeline or watch auto-progress |

## Common Tasks

### Change Profile Information
1. Profile → Edit Profile
2. Update Name or Bio
3. Save Changes

### Create a Quiz
1. Reels have automatic quizzes
2. Take them from reel detail page
3. See score and explanations instantly

### Switch to Dark Mode
1. Click Moon icon (top-right)
2. Theme switches immediately
3. Preference saved to browser

### Upload New Content
1. Click Upload in navbar
2. Fill form with:
   - Title (required)
   - Description
   - Tags (comma-separated)
   - Difficulty level
3. Submit form
4. Reel appears in feed immediately

### Access Settings
1. Profile → Settings tab
2. Change password, privacy, notifications
3. Chat with AI for support

## Keyboard Shortcuts

- `Space`: Play/Pause (when focused on video)
- `M`: Mute/Unmute
- `↑`: Volume up
- `↓`: Volume down

## Demo Data

5 sample reels included:
- React Hooks Explained
- TypeScript Type Guards
- CSS Grid Layout
- Next.js 15 App Router
- JavaScript Async/Await

## Need Help?

1. **In-App**: Profile → Settings → Chat with AI
2. **FAQ**: Profile → Settings → FAQ
3. **Contact**: Profile → Settings → Contact Support
4. **Code**: Check API_DOCUMENTATION.md

## Tips & Tricks

1. **Multi-Account Testing**: Register multiple accounts to test social features
2. **Offline Mode**: All features work without internet once loaded
3. **Reset Data**: Clear browser localStorage to start fresh
4. **Mobile Friendly**: App is fully responsive on phones
5. **Video Testing**: Videos have built-in controls and auto-loop

## Browser Compatibility

✅ Chrome (latest)
✅ Firefox (latest)
✅ Safari (latest)
✅ Edge (latest)

## Keyboard Navigation

- Tab: Navigate between buttons
- Enter: Activate buttons/links
- Escape: Close modals
- Arrow keys: Scroll content

---

Enjoy learning with EduVexa!
