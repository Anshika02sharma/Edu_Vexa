export const mockReels = [
  {
    id: "1",
    title: "React Hooks Explained",
    description: "Master React Hooks in 60 seconds. Learn useState, useEffect, and custom hooks essentials.",
    thumbnail: "/react-hooks.jpg",
    creator: {
      name: "Sarah Chen",
      followers: "25K",
      avatar: "/diverse-avatars.png",
    },
    tags: ["React", "JavaScript", "Web Dev"],
    difficulty: "Intermediate",
    duration: "1:00",
    views: "45.2K",
    likes: 3240,
    comments: 156,
    saves: 892,
    summary:
      "React Hooks revolutionized functional components by allowing state management and side effects. useState lets you manage component state, useEffect handles side effects like data fetching, and custom hooks enable logic reuse across components. Mastering these fundamentals is essential for modern React development.",
  },
  {
    id: "2",
    title: "TypeScript Type Guards",
    description: "Learn how to use type guards for bulletproof TypeScript code.",
    thumbnail: "/typescript-logo.png",
    creator: {
      name: "John Dev",
      followers: "18K",
      avatar: "/diverse-avatars.png",
    },
    tags: ["TypeScript", "JavaScript", "Best Practices"],
    difficulty: "Intermediate",
    duration: "1:30",
    views: "32.1K",
    likes: 2150,
    comments: 89,
    saves: 654,
    summary:
      "Type guards are TypeScript mechanisms to narrow types within conditional blocks. Common patterns include typeof checks for primitives, instanceof for class instances, and custom type predicates. They ensure type safety and enable better IDE autocompletion, making code more reliable and maintainable.",
  },
  {
    id: "3",
    title: "CSS Grid Layout Basics",
    description: "Build responsive layouts with CSS Grid. From basics to advanced techniques.",
    thumbnail: "/css-grid.jpg",
    creator: {
      name: "Alex Design",
      followers: "42K",
      avatar: "/diverse-avatars.png",
    },
    tags: ["CSS", "Design", "Web Dev"],
    difficulty: "Beginner",
    duration: "2:15",
    views: "68.9K",
    likes: 5120,
    comments: 234,
    saves: 1203,
    summary:
      "CSS Grid is a powerful 2D layout system for web design. Define grid containers with display: grid, specify rows and columns with grid-template-*, and place items precisely. Grid gaps add spacing, and fr units create responsive layouts. Combine with media queries for mobile-first design.",
  },
  {
    id: "4",
    title: "Next.js 15 App Router",
    description: "Deep dive into Next.js 15 App Router with file-based routing.",
    thumbnail: "/nextjs-logo.png",
    creator: {
      name: "Sarah Chen",
      followers: "25K",
      avatar: "/diverse-avatars.png",
    },
    tags: ["Next.js", "React", "Full Stack"],
    difficulty: "Advanced",
    duration: "3:45",
    views: "52.3K",
    likes: 4320,
    comments: 187,
    saves: 1045,
    summary:
      'The App Router in Next.js 15 uses the app directory for file-based routing. Create pages with page.tsx files, layouts with layout.tsx, and API routes in api folders. Server components by default, client-side capabilities with "use client", and built-in optimizations make modern full-stack development seamless.',
  },
  {
    id: "5",
    title: "JavaScript Async/Await",
    description: "Master async/await for clean asynchronous code.",
    thumbnail: "/javascript-code.png",
    creator: {
      name: "Code Master",
      followers: "55K",
      avatar: "/diverse-avatars.png",
    },
    tags: ["JavaScript", "Async", "Programming"],
    difficulty: "Beginner",
    duration: "2:00",
    views: "95.2K",
    likes: 7890,
    comments: 456,
    saves: 2134,
    summary:
      "Async/await simplifies Promise handling with readable, synchronous-looking code. Mark functions with async to use await for promises, enabling sequential execution without callback pyramids. Combine with try/catch for error handling. Understanding async/await is crucial for modern JavaScript development.",
  },
]

export const mockQuizzes = [
  {
    reelId: "1",
    questions: [
      {
        question: "What is the primary purpose of the useState hook?",
        options: [
          "To manage side effects in functional components",
          "To manage state in functional components",
          "To optimize component performance",
          "To handle component lifecycle",
        ],
        correctAnswer: 1,
        explanation:
          "useState allows functional components to have state. It returns an array with the current state value and a function to update it.",
      },
      {
        question: "Which hook would you use to fetch data from an API?",
        options: ["useState", "useContext", "useEffect", "useReducer"],
        correctAnswer: 2,
        explanation:
          "useEffect is the hook used for side effects like fetching data. Place the fetch call inside useEffect with appropriate dependencies.",
      },
      {
        question: "What is a custom hook?",
        options: [
          "A built-in React hook",
          "A JavaScript function that uses other hooks",
          "A component that uses hooks",
          "A special type of state management",
        ],
        correctAnswer: 1,
        explanation:
          "Custom hooks are JavaScript functions that can call other hooks. They enable logic reuse across multiple components.",
      },
      {
        question: "When should you use useCallback?",
        options: [
          "Always with useEffect",
          "To memoize expensive computations",
          "To memoize callback functions and optimize performance",
          "To handle API calls",
        ],
        correctAnswer: 2,
        explanation:
          "useCallback memoizes functions, preventing unnecessary re-renders of child components that receive the function as a prop.",
      },
      {
        question: "What is the purpose of dependency arrays in useEffect?",
        options: [
          "To store component state",
          "To specify when the effect should run",
          "To prevent infinite loops",
          "To manage component lifecycle",
        ],
        correctAnswer: 1,
        explanation:
          "Dependency arrays determine when useEffect runs. An empty array means run once on mount; including values means run when those values change.",
      },
    ],
  },
]
