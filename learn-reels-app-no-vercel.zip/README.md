# EduVexa - Bite-Sized Learning Platform

A modern, full-stack micro-learning application combining Instagram Reels with Udemy course structure. Built with Next.js 16, React 19, and TypeScript.

## Features

### Core Learning Experience
- **Vertical Reel Feed**: TikTok-style vertical scrolling with snap-to-section behavior
- **Video Player**: Full-featured player with play/pause, volume control, and mute toggle
- **Autoplay with Sound**: Smart autoplay detection with fallback overlay for browser blocking
- **Single Video Playback**: Only one video plays at a time across the entire app
- **Practice Quizzes**: AI-powered MCQ questions with explanations and scoring
- **AI Summaries**: Generated text summaries for each reel

### Creator Tools
- **Upload Reels**: Create learning content with title, description, tags, and difficulty
- **Micro-courses**: Organize multiple reels into structured learning paths
- **Analytics Dashboard**: Track views, likes, saves, and course completion rates
- **Creator Profile**: Display follower stats and learning content

### User Account Management
- **Authentication**: Email/password login and registration
- **Edit Profile**: Update name, bio, and avatar
- **Profile Dashboard**: View stats, saved courses, and learning progress
- **Settings**: Account, support, and notification preferences
- **AI Chatbot Support**: 24/7 bot for common questions

### Visual Design
- **Dark Mode**: Full dark theme support with persistent preferences
- **Light Creme Theme**: Soft background (#FBF7F2) for light mode
- **Responsive Layout**: Mobile-first design that scales to desktop
- **Modern Components**: Rounded cards, subtle shadows, smooth transitions
- **Red Accent Color**: Vibrant red (#EF4444) for interactive elements

## Quick Start

### Prerequisites
- Node.js 18+
- npm or pnpm

### Installation
\`\`\`bash
# Clone the project
git clone <repository-url>

# Install dependencies
npm install

# Run development server
npm run dev
\`\`\`

The app opens at `http://localhost:3000`

### Demo Credentials
- Email: `demo@eduvexa.com`
- Password: `demo123`

## Project Structure

\`\`\`
eduvexa/
├── app/
│   ├── auth/              # Login/Register page
│   ├── api/               # Backend API routes
│   ├── creator/           # Creator dashboard
│   ├── microcourse/       # Micro-course viewer
│   ├── my-learning/       # User's saved courses
│   ├── profile/           # Profile & settings
│   ├── reel/              # Individual reel viewer
│   ├── upload/            # Reel upload
│   └── page.tsx           # Home feed
├── components/
│   ├── navigation.tsx     # Top navbar
│   ├── reel-feed.tsx      # Vertical feed component
│   ├── reel-card.tsx      # Individual reel card
│   ├── reel-player.tsx    # Video player with controls
│   ├── comment-section.tsx # Comments UI
│   ├── quiz-modal.tsx     # Quiz interface
│   └── ...
├── lib/
│   ├── mock-data.ts       # Sample reels and quizzes
│   └── utils.ts           # Helper functions
└── public/                # Static assets
\`\`\`

## API Endpoints

All endpoints are fully functional with mock data:

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/feed` | Get personalized reel feed |
| GET | `/api/reels/:id` | Get reel details |
| POST | `/api/reels/upload` | Upload new reel |
| GET | `/api/quiz?reelId=:id` | Get quiz questions |
| GET | `/api/comments?reelId=:id` | Get reel comments |
| POST | `/api/comments` | Add comment |

## Technology Stack

- **Frontend**: React 19, Next.js 16 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4, shadcn/ui components
- **State Management**: React hooks, localStorage
- **Icons**: Lucide React
- **Authentication**: localStorage (mock)
- **Data**: Mock JSON in-memory storage

## Key Features Implementation

### Authentication Flow
1. User visits app → redirected to `/auth` if not logged in
2. Login/Register with email and password
3. Token stored in localStorage
4. All pages check for token and redirect if missing
5. Logout clears token and redirects to auth

### Video Playback
1. Promise-based play() with proper abort handling
2. Global video ref tracking prevents concurrent playback
3. Auto-play with sound on reel detail page
4. Fallback overlay for browser-blocked autoplay
5. Smooth controls: play/pause, volume, mute, progress

### Theme System
1. Preference saved to localStorage
2. Applied to document.documentElement with `dark` class
3. CSS variables switch between light and dark palettes
4. All components respect theme via Tailwind dark mode
5. Light theme: soft creme (#FBF7F2)
6. Dark theme: full slate-950 background

### Edit Profile
1. Modal form overlays current profile
2. Changes saved to localStorage
3. Form includes name, bio, and email fields
4. Email field disabled (read-only)
5. Success feedback with button state

## Customization

### Colors
Edit `app/globals.css` to customize the color scheme:
\`\`\`css
:root {
  --background: 0 0% 98.8%;    /* Light creme */
  --accent: 0 84% 60%;          /* Red */
}

.dark {
  --background: 0 0% 8%;        /* Dark slate */
  --accent: 0 84% 60%;          /* Red */
}
\`\`\`

### Adding New Reels
Update `lib/mock-data.ts` with new reel objects:
\`\`\`typescript
export const mockReels = [
  {
    id: "6",
    title: "Your Title",
    description: "Your description",
    // ... other fields
  }
]
\`\`\`

## Performance Optimizations

- Image optimization with Next.js Image component
- CSS-in-JS with Tailwind reduces bundle size
- Mock data loaded from memory (no database calls)
- localStorage for instant persistence
- Lazy loading of components via code splitting

## Known Limitations

- Mock data resets on page refresh
- No real video upload (uses demo video URL)
- Comments stored in-memory (not persistent)
- Quiz scores not saved permanently
- Single-device testing only

## Future Enhancements

- Real database integration (Supabase/Neon)
- Actual video hosting (cloud Blob/AWS S3)
- Real-time notifications
- Social features (follow, messaging)
- Advanced analytics
- AI-powered content recommendations
- Live streaming capabilities
- Mobile app version

## Troubleshooting

### Videos won't play
- Check browser allows video playback
- Ensure video URL is accessible
- Use fallback overlay to play with sound

### Dark mode not applying
- Clear localStorage and refresh
- Check CSS variables in globals.css
- Ensure `dark` class is on document root

### Auth not working
- Clear localStorage: `localStorage.clear()`
- Try demo credentials first
- Check browser dev tools for errors

### Slow performance
- Reduce number of reels in mock-data
- Optimize images before uploading
- Check browser dev tools Performance tab

## License

MIT License - Free to use and modify

## Support

For issues or questions, use the AI Chatbot in Profile → Settings → Chat with AI Assistant.

---

**EduVexa** - Scroll. Learn. Grow. 🎓
